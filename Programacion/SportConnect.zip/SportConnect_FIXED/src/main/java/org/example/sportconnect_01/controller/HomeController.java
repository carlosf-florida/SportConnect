package org.example.sportconnect_01.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.example.sportconnect_01.model.ClaseDeportiva;
import org.example.sportconnect_01.model.MensajeChat;
import org.example.sportconnect_01.model.Usuario;
import org.example.sportconnect_01.service.DataStore;
import org.example.sportconnect_01.service.Session;
import org.example.sportconnect_01.util.AlertUtils;
import org.example.sportconnect_01.util.SceneManager;

public class HomeController {

    @FXML private Label appNameLabel;
    @FXML private Label bienvenidaLabel;
    @FXML private Label tipoUsuarioLabel;
    @FXML private Label roleStatusLabel;
    @FXML private Label chatEstadoLabel;
    @FXML private Label statClasesLabel;
    @FXML private Label statAlumnosLabel;
    @FXML private Label statProductosLabel;
    @FXML private Button profesorButton;
    @FXML private Button adminButton;
    @FXML private Button rolAlumnoButton;
    @FXML private Button rolProfesorButton;
    @FXML private ComboBox<ClaseDeportiva> chatClaseCombo;
    @FXML private ListView<String> chatListView;
    @FXML private TextField chatMensajeField;

    @FXML
    private void initialize() {
        Usuario usuario = Session.getUsuarioActual();

        // Indicar modo BD o local en el nombre de la app
        String modoLabel = DataStore.isUsandoBaseDeDatos() ? "⚽ SportConnect  🟢 MySQL" : "⚽ SportConnect  🔴 Modo local";
        appNameLabel.setText(modoLabel);

        statClasesLabel.setText(String.valueOf(DataStore.getClases().size()));
        statAlumnosLabel.setText(String.valueOf(DataStore.contarAlumnos()));
        statProductosLabel.setText(String.valueOf(DataStore.getProductos().size()));

        chatClaseCombo.setItems(FXCollections.observableArrayList(DataStore.getClases()));
        if (!chatClaseCombo.getItems().isEmpty()) chatClaseCombo.getSelectionModel().selectFirst();
        cargarChat();

        if (usuario != null) {
            bienvenidaLabel.setText("Hola, " + usuario.getNombreCompleto());
            tipoUsuarioLabel.setText("@" + usuario.getNick());
            actualizarVistaRol(usuario);
        } else {
            bienvenidaLabel.setText("Bienvenido");
            tipoUsuarioLabel.setText("");
            roleStatusLabel.setText("Sin sesión");
            profesorButton.setVisible(false); profesorButton.setManaged(false);
            adminButton.setVisible(false); adminButton.setManaged(false);
            rolAlumnoButton.setDisable(true); rolProfesorButton.setDisable(true);
        }
    }

    private void actualizarVistaRol(Usuario usuario) {
        boolean esProfesor = usuario.esProfesor() || usuario.esAdmin();
        boolean esAdmin    = usuario.esAdmin();
        profesorButton.setVisible(esProfesor); profesorButton.setManaged(esProfesor);
        adminButton.setVisible(esAdmin);       adminButton.setManaged(esAdmin);

        if (usuario.esAdmin()) {
            roleStatusLabel.setText("Modo actual: Admin");
            rolAlumnoButton.setDisable(true); rolProfesorButton.setDisable(true);
            rolAlumnoButton.setText("Alumno"); rolProfesorButton.setText("Profesor");
        } else {
            roleStatusLabel.setText("Modo actual: " + usuario.getRol());
            rolAlumnoButton.setDisable(usuario.esAlumno());
            rolProfesorButton.setDisable(usuario.esProfesor());
            rolAlumnoButton.setText(usuario.esAlumno() ? "✓ Alumno" : "Alumno");
            rolProfesorButton.setText(usuario.esProfesor() ? "✓ Profesor" : "Profesor");
        }
    }

    private void cambiarRol(String nuevoRol) {
        Usuario usuario = Session.getUsuarioActual();
        if (usuario == null || usuario.esAdmin()) return;
        if (usuario.getRol().equalsIgnoreCase(nuevoRol)) return;
        usuario.setRol(nuevoRol);
        DataStore.actualizarUsuarioPorId(usuario);
        Session.setUsuarioActual(usuario);
        actualizarVistaRol(usuario);
        AlertUtils.mostrarInfo("Rol actualizado", "Ahora estás usando la app como " + usuario.getRol() + ".");
    }

    private void cargarChat() {
        chatListView.getItems().clear();
        for (MensajeChat m : DataStore.getUltimosMensajes(10))
            chatListView.getItems().add(m.getVistaCorta());
        if (chatListView.getItems().isEmpty())
            chatListView.getItems().add("Todavía no hay mensajes en el chat.");
        chatEstadoLabel.setText("Chat general de clases");
    }

    @FXML
    private void onEnviarChatClick() {
        Usuario usuario = Session.getUsuarioActual();
        ClaseDeportiva clase = chatClaseCombo.getValue();
        String texto = chatMensajeField.getText() == null ? "" : chatMensajeField.getText().trim();

        if (usuario == null) { AlertUtils.mostrarError("Debes iniciar sesión para enviar mensajes."); return; }
        if (clase == null)   { AlertUtils.mostrarError("Selecciona una clase para enviar el mensaje."); return; }
        if (texto.isEmpty()) { AlertUtils.mostrarError("Escribe un mensaje antes de enviarlo."); return; }

        try {
            DataStore.enviarMensaje(usuario.getId(), clase.getId(), texto);
            chatMensajeField.clear();
            cargarChat();
        } catch (RuntimeException e) {
            AlertUtils.mostrarError("No se pudo enviar el mensaje: " + e.getMessage());
        }
    }

    @FXML private void onCambiarAlumnoClick()  { cambiarRol("Alumno"); }
    @FXML private void onCambiarProfesorClick() { cambiarRol("Profesor"); }
    @FXML private void onVerClasesClick()     { SceneManager.cambiarVista("clases-view.fxml",    "SportConnect - Clases"); }
    @FXML private void onMisClasesClick()     { SceneManager.cambiarVista("mis-clases-view.fxml","SportConnect - Mis clases"); }
    @FXML private void onVerProfesoresClick() { SceneManager.cambiarVista("profesores-view.fxml","SportConnect - Profesores"); }
    @FXML private void onProductosClick()     { SceneManager.cambiarVista("productos-view.fxml", "SportConnect - Tienda"); }
    @FXML private void onCarritoClick()       { SceneManager.cambiarVista("carrito-view.fxml",   "SportConnect - Carrito"); }
    @FXML private void onMiPerfilClick()      { SceneManager.cambiarVista("perfil-view.fxml",    "SportConnect - Perfil"); }
    @FXML private void onProfesorPanelClick() { SceneManager.cambiarVista("profesor-view.fxml",  "SportConnect - Panel Profesor"); }
    @FXML private void onAdminClick()         { SceneManager.cambiarVista("admin-view.fxml",     "SportConnect - Panel Admin"); }
    @FXML private void onCerrarSesionClick()  { Session.cerrarSesion(); SceneManager.cambiarVista("login-view.fxml", "SportConnect - Login"); }
}
