package org.example.sportconnect_01.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Utilidad única para conectar SportConnect con MySQL.
 *
 * La configuración se lee desde src/main/resources/db.properties.
 * Si ese archivo no se encuentra, se usan los datos reales de la EC2.
 */
public class DBUtil {

    private static final String DEFAULT_HOST = "52.91.236.71";
    private static final String DEFAULT_PORT = "3306";
    private static final String DEFAULT_DATABASE = "sportconnect";
    private static final String DEFAULT_USER = "sportconnect_user";
    private static final String DEFAULT_PASSWORD = "sportconnect123";

    private static final String URL;
    private static final String USER;
    private static final String PASSWORD;

    static {
        cargarDriverMySQL();

        Properties props = cargarPropiedades();

        String host = props.getProperty("db.host", DEFAULT_HOST).trim();
        String port = props.getProperty("db.port", DEFAULT_PORT).trim();
        String database = props.getProperty("db.database", DEFAULT_DATABASE).trim();
        USER = props.getProperty("db.user", DEFAULT_USER).trim();
        PASSWORD = props.getProperty("db.password", DEFAULT_PASSWORD);

        URL = "jdbc:mysql://" + host + ":" + port + "/" + database
                + "?useSSL=false"
                + "&serverTimezone=UTC"
                + "&allowPublicKeyRetrieval=true"
                + "&characterEncoding=UTF-8"
                + "&connectTimeout=5000"
                + "&socketTimeout=10000";

        System.out.println("[DBUtil] Conectando a MySQL: " + host + ":" + port + "/" + database);
    }

    private static void cargarDriverMySQL() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new ExceptionInInitializerError("No se encontró mysql-connector-j en el pom.xml");
        }
    }

    private static Properties cargarPropiedades() {
        Properties props = new Properties();

        try (InputStream input = DBUtil.class.getResourceAsStream("/db.properties")) {
            if (input != null) {
                props.load(input);
            }
        } catch (IOException e) {
            System.err.println("[DBUtil] No se pudo leer db.properties: " + e.getMessage());
        }

        return props;
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static String probarConexion() {
        try (Connection ignored = getConnection()) {
            return null;
        } catch (SQLException e) {
            System.err.println("[DBUtil] Error conectando con MySQL: " + e.getMessage());
            return e.getMessage();
        }
    }

    @Deprecated
    public static boolean testConexionBoolean() {
        return probarConexion() == null;
    }
}
